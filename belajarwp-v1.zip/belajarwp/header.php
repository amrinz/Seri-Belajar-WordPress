<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta <?php bloginfo( 'charset' ); ?>>
	<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">

	<link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri().'/favicon.ico'; ?>" />

	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

	<?php wp_head(); ?>

</head>
<body <?php body_class(); ?> id="lmd-body">
	
	<div class="header">
		<div class="container">
			<h1><a href="<?php echo home_url(); ?>"><?php echo get_bloginfo('name'); ?></a></h1>
			<p><?php echo get_bloginfo('description'); ?></p>
			<hr>
		</div>
	</div>