<?php

include_once('inc/wordpress-bootstrap-4-pagination.php');

/* theme support */
add_theme_support( 'title-tag' );

//Load some scripts and styles
function lmd_scripts_styles() {
	wp_deregister_script( 'jquery' );
	wp_register_script( 'jquery', get_template_directory_uri() . '/js/jquery-3.5.1.min.js');
	wp_enqueue_script( 'jquery' );

	wp_enqueue_script('bt_js', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '4.5.2', true );

	//CSS
	wp_enqueue_style('bt_css', get_template_directory_uri() . '/css/bootstrap.min.css', false ,'4.5.2');
	wp_enqueue_style('style_css', get_stylesheet_directory_uri() . '/style.css');
}
add_action('wp_enqueue_scripts', 'lmd_scripts_styles');