<?php get_header(); ?>

	<section class="lmd-main">
		<div class="container">

			<section class="row">

				<main class="col-lg-8 lmd-content">
					
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
						<article id="post-<?php the_ID(); ?>"  <?php post_class(); ?> role="article">
	
							<h2 class="post-title"><a href="<?php the_permalink(); ?>" title="Continue reading <?php the_title(); ?>"><?php the_title(); ?></a></h2>
							
							<ul class="list-inline post-meta">
								<li class="list-inline-item post-author">By&nbsp;&nbsp;<?php the_author_posts_link(); ?></li>
								<li class="list-inline-item post-date"><i class="fa fa-clock-o"></i>&nbsp;&nbsp;<?php the_time( get_option( 'date_format' ) ); ?></li>
								<li class="list-inline-item post-category"><?php the_category(' '); ?></li>
							</ul>			

							<section class="post-body">
								<?php the_excerpt(); ?>
							</section>

						</article>	
						
					<?php endwhile;

						wp_boostrap_4_pagination();
					
					else:

						echo 'belum ada artikel';
					
					endif; ?>

				</main>
				
				<?php get_sidebar(); ?>

			</section><!--/row-->

		</div><!--/container-->
	</section><!--/lmd main-->

<?php get_footer(); ?>