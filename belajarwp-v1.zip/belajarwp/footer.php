	<footer class="lmd-footer">
		<div class="container">
			
			<hr>
			<p class="copyright">Copyright &copy; <?php echo date('Y'); ?> . <?php bloginfo('name'); ?> . All rights reserved</p>

		</div><!--/container-->
	</footer><!--/section-->

	<?php wp_footer(); ?>

	</body>
</html>