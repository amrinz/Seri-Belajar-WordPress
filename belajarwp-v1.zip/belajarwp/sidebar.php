<aside class="col-lg-4 lmd-sidebar">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar') ) : ?>
		<p><a href="<?php echo home_url(); ?>/wp-admin/widgets.php">Add New Widget</a></p>
	<?php endif; ?>
</aside>